# Unified Communications (UC)

- Webex Calling & MS Teams Integration
- SIP Trunking & Cloud PSTN
- Migration from Avaya to Webex
- UC Analytics & Governance
